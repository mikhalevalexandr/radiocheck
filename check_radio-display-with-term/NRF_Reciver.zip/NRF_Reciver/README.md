Описание

https://istarik.ru/blog/stm32/127.html
 
 
[![Donate](https://istarik.ru/uploads/images/00/00/01/2020/04/12/ff1b11.png)](https://istarik.ru/don.html) 
